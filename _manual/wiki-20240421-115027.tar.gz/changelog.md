---
title: Changelog
description: 
published: true
date: 2024-04-21T08:03:07.229Z
tags: 
editor: markdown
dateCreated: 2024-04-14T15:04:12.312Z
---

# Changelog



## Projets en cours
- Ecrire la documentation
- Synchronisation avec Obsidian
- Instances multi-langues
## Peut-être, quelque part dans le futur
- Authentification unifiée
- ~~Améliorer le transcoding~~ Nécessite un GPU dédié
## Notes de version

### 1.0 alpha - xx avril 2024
- Stack de download
- Medias avec Jellyfin/Jellyseerr
- Espace de documentation