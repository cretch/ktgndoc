---
title: Jellyfin
description: 
published: true
date: 2024-04-16T17:51:04.651Z
tags: 
editor: markdown
dateCreated: 2024-04-14T15:04:33.113Z
---

# Jellyfin	
Jellyfin est un centre de lecture multimédia. Vous devez disposer d'un identifiant crée pour vous (il est partagé avec [Jellyseerr](/jellyseerr) ).

Il est accessible de plusieurs manières:
- Via le web, en cliquant sur [ce lien](https://jellyfin.ktgn.ne)
- Via une app ([Android](/https://play.google.com/store/apps/details?id=org.jellyfin.mobile), [Apple](/https://apps.apple.com/us/app/jellyfin-mobile/id1480192618?mt=8) ou les [TV Android](/https://play.google.com/store/apps/details?id=org.jellyfin.androidtv))

Selon la configuration de la TV, vous pouvez aussi "caster" Jellyfin. Sur ma vieille Smart TV, j'ai du acquérir un Google Chromecast.

> La documentation est rédigée en s'appuyant sur la version web. Les grands principes sont identiques sur les applications
{.is-info}

## Connexion

